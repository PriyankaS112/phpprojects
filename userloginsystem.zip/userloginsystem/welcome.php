<?php
session_start();
if(isset($_SESSION['log']))
{

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Welcome</h1>
<a href="index.php">logout</a>
</body>
</html>
}
else{
	echo "Please enter correct details";
    header("refresh:2;url=index.php");
}
?>