<?php
$Username=$_POST['Username'];
$Password=$_POST['Password'];
session_start();

$con=mysqli_connect("localhost","root","","login");
$result=mysqli_query(query)($con,"SELECT * FROM 'login_info' WHERE 'Username'='$Username' && 'Password'='$Password');
	$count=mysqli_num_rows($result);
	if($count==1)
	{
	echo "Login success";
	$_SESSION['log']=1;
	header("refresh:2;url=welcome.php");
    }
    else
    {
    echo "Please enter correct details";
    header("refresh:2;url=index.php");
    }
?>