<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>userloginsystem</title>
</head>
<body>
	<form method="POST" action="ulogin.php">
		Enter Username : <input type="text" name="Username" ><br><br>
		Enter Password : <input type="Password" name="Password"><br><br>
		<input type="submit" value="Login">
	</form>

</body>
</html>
<?php
session_destroy();
?>